package com.AngelProjects.RPSD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpsdApplication {

	public static void main(String[] args) {
		SpringApplication.run(RpsdApplication.class, args);
	}

}
