package com.AngelProjects.RPSD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpsdApplicationTests {

	@Test
	void contextLoads() {
	}

}
